package com.trivia.game.triviaspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TriviaSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TriviaSpringBootApplication.class, args);
	}

}
